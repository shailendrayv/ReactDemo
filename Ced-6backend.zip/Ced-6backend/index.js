const express = require('express');
const app = express();
const port = 8081;
app.use(express.json());
app.use(express.urlencoded({ extended: true }));


app.get('/', (req, res) => {
    res.send('Hello World!');
})

app.get('/test1', (req, res) => {
    res.send('Hello World! shailendra yadav ');
})


app.get("/r1/*", (req, res) => {
    res.send('Hello World! shailendra yadav2 ');
})

app.get('/test3/:p1', (req, res) => {
    const v1 = req.params.p1;
    console.log(req.body);
    res.send(`this is code for test3 with parameters ${v1}`);

});



app.listen(port, ()=>{
    console.log(`Server is running on port ${port}`);
});
